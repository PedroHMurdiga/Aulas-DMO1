
import calculadora.Calculadora;
import org.junit.Test;
import static org.junit.Assert.*;

public class CalculadoraTest {
    
    public CalculadoraTest() {
    }
    
    @Test
    public void testSomar(){
        System.out.println("testSomar()");
        Calculadora casio = new Calculadora();
        
        casio.somar(13.5, 5.25);
        
        double resultado = casio.getResultado();
        double resultadoExp = 18.75;
        
        assertEquals(resultadoExp, resultado, 0.0);
    }
    
    @Test
    public void testDividir1(){
        System.out.println("testDividir1()");
        Calculadora casio = new Calculadora();
        
        casio.dividir(13.5, 5);
        
        Exception ex = assertThrows( IllegalArgumentException.class , () -> {
           casio.dividir(13.5, 0.0); 
        });
        
        assertEquals( ex.getMessage(), "b não pode assumir valor zero (0.0)");
    }
    
    @Test
    public void testDividir2(){
        System.out.println("testDividir2()");
        Calculadora casio = new Calculadora();
        
        casio.dividir(14.0, 2.0);
        
        double resultado = casio.getResultado();
        double resultadoExp = 18.75;
        
        assertEquals(resultadoExp, resultado, 0.0);
    }

    
}
