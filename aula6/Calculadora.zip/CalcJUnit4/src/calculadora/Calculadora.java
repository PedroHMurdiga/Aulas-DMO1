/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculadora;

/**
 *
 * @author aluno
 */
public class Calculadora {
    
    private double resultado;

    public Calculadora() {
        resultado = Double.NaN;
    }

    public double getResultado() {
        return resultado;
    }

    private void setResultado(double resultado) {
        if (resultado == Double.NaN){
            throw new IllegalArgumentException("Resultado não pode ser NaN");
        }
        this.resultado = resultado;
    }
    
    public void somar(double a, double b){
        double calculo;
        calculo = a + b;
        setResultado(calculo);
    }
    
    public void subtrair(double a, double b){
        double calculo;
        calculo = a - b;
        setResultado(calculo);
    }
    
    public void multiplicar(double a, double b){
        double calculo;
        calculo = a * b;
        setResultado(calculo);
    }
    
    public void dividir(double a, double b){
        
        if (b == 0.0){
            throw new IllegalArgumentException("b não pode assumir valor zero (0.0)");
        }
        
        double calculo;
        calculo = a / b;
        setResultado(calculo);
    }
    
}
