/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import calculadora.Calculadora;
/**
 *
 * @author aluno
 */
public class Main {

    public static void main(String[] args){
        Calculadora casio = new Calculadora();
        
        casio.somar(13.5, 5.25);
        System.out.println(casio.getResultado());
    }
}
